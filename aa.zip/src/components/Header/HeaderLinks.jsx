import React, { Component } from 'react'
import {
  Navbar,
  Nav,
  NavItem,
  NavDropdown,
  MenuItem,
  FormGroup,
  FormControl,
  InputGroup
} from 'react-bootstrap'
import { NavLink } from 'react-router-dom'

class HeaderLinks extends Component {
  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value })
  }
  render () {
    return (
      <div>
        <Nav pullRight>
          <NavItem>
            <NavLink to={'/pages/lock-screen-page'} className='nav-link'>
              <i className='pe-7s-mail' /> Мэдэгдэл
              <span className='notification'>5</span>
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink to={'/pages/lock-screen-page'} className='nav-link'>
              <i className='pe-7s-help1' /> Тусламж
            </NavLink>
          </NavItem>
        </Nav>
      </div>
    )
  }
}
export default HeaderLinks

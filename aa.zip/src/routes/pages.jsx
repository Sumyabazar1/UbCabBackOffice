import LoginPage from 'views/Pages/LoginPage.jsx'
import RegisterPage from 'views/Pages/RegisterPage.jsx'

var pagesRoutes = [
  {
    path: '/pages/login-page',
    name: 'Нэвтрэх',
    mini: 'Н',
    component: LoginPage
  },
  {
    path: '/pages/register-page',
    name: 'Бүртгүүлэх',
    mini: 'Б',
    component: RegisterPage
  }
]

export default pagesRoutes

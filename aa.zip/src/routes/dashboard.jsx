import Dashboard from 'views/Dashboard/Dashboard.jsx'
import Buttons from 'views/Components/Buttons.jsx'
import GridSystem from 'views/Components/GridSystem.jsx'
import Panels from 'views/Components/Panels.jsx'
import SweetAlert from 'views/Components/SweetAlertPage.jsx'
import Notifications from 'views/Components/Notifications.jsx'
import Icons from 'views/Components/Icons.jsx'
import Typography from 'views/Components/Typography.jsx'
import RegularForms from 'views/Forms/RegularForms.jsx'
import ExtendedForms from 'views/Forms/ExtendedForms.jsx'
import ValidationForms from 'views/Forms/ValidationForms.jsx'
import Wizard from 'views/Forms/Wizard/Wizard.jsx'
import RegularTables from 'views/Tables/RegularTables.jsx'
import ExtendedTables from 'views/Tables/ExtendedTables.jsx'
import Enrollments from 'views/Tables/Enrollments.jsx'
import EnrollmentsAdd from 'views/Tables/EnrollmentsAdd.jsx'
import Drivers from 'views/Tables/Drivers.jsx'
import Trips from 'views/Tables/Trips.jsx'
import Users from 'views/Tables/Users.jsx'
import Operators from 'views/Tables/Operators.jsx'
import RealtimeLocation from 'views/Maps/RealtimeLocation.jsx'
import DispatchRequest from 'views/Maps/DispatchRequest.jsx'
import Charts from 'views/Charts/Charts.jsx'
import Calendar from 'views/Calendar/Calendar.jsx'
import UserPage from 'views/Pages/UserPage.jsx'
import EnrollmentForms from 'views/Forms/EnrollmentForms.jsx'

var dashboardRoutes = [
  {
    path: '/dashboard',
    name: 'Ерөнхий',
    icon: 'pe-7s-graph',
    component: Dashboard
  },
  {
    collapse: true,
    path: '/forms',
    name: 'Бүртгэл',
    state: 'openForms',
    icon: 'pe-7s-note2',
    views: [
      {
        path: '/forms/drivers',
        name: 'Жолооч',
        mini: 'Ж',
        component: Drivers
      },
      {
        path: '/forms/add-enrollments',
        name: 'Нэмэлт хүсэлт',
        mini: 'Н',
        component: EnrollmentsAdd
      },
      {
        path: '/forms/enrollments',
        name: 'Шинэ хүсэлт',
        mini: 'Ш',
        component: Enrollments
      },
      {
        path: '/forms/users',
        name: 'Хэрэглэгч',
        mini: 'Х',
        component: Users
      }
    ]
  },
  {
    collapse: true,
    path: '/tables',
    name: 'Үйлчилгээ',
    state: 'openTables',
    icon: 'pe-7s-map-2',
    views: [
      {
        path: '/trips',
        name: 'Аяллын түүх',
        mini: 'АТ',
        component: Trips
      },
      {
        path: '/tables/extended-tables',
        name: 'Жолоочийн санал',
        mini: 'ЖС',
        component: ExtendedTables
      },
      {
        path: '/tables/react-table',
        name: 'Хэрэглэгчийн санал',
        mini: 'ХС',
        component: ExtendedTables
      }
    ]
  },
  {
    collapse: true,
    path: '/maps',
    name: 'Байршил',
    state: 'openMaps',
    icon: 'pe-7s-map-marker',
    views: [
      {
        path: '/maps/location',
        name: 'Шууд хяналт',
        mini: 'Ш',
        component: RealtimeLocation
      },
      {
        path: '/maps/dispatch',
        name: 'Дуудлага',
        mini: 'Б',
        component: DispatchRequest
      }
    ]
  },
  { path: '/charts', name: 'Тайлан', icon: 'pe-7s-graph1', component: Charts },
  {
    collapse: true,
    path: '/pages',
    name: 'Урамшуулал',
    state: 'openPages',
    icon: 'pe-7s-gift',
    views: [
      {
        path: '/components/buttons',
        name: 'Урамшуулал',
        mini: 'У',
        component: Buttons
      },
      {
        path: '/components/grid-system',
        name: 'Урамшууллын тайлан',
        mini: 'Т',
        component: RegularForms
      }]
  },
  {
    collapse: true,
    path: '/components',
    name: 'Удирдлага',
    state: 'openComponents',
    icon: 'pe-7s-plugin',
    views: [{
      path: '/tables/company',
      name: 'Оператор',
      mini: 'О',
      component: Operators
    } ]
  },
  {
    collapse: true,
    path: '/settings',
    name: 'Тохиргоо',
    state: 'openSettings',
    icon: 'pe-7s-settings',
    views: [
      {
        path: '/settings/company',
        name: 'Нууц үг',
        mini: 'Н',
        component: ExtendedForms
      },
      {
        path: '/settings/account/create',
        name: 'Системийн тохиргоо',
        mini: 'СТ',
        invisible: true,
        component: Buttons
      },
      {
        path: '/settings/account/edit/:id',
        name: 'Бусад',
        mini: 'Б',
        invisible: true,
        component: RegularTables
      },
      {
        path: '/settings/account',
        name: 'Апп тохиргоо',
        mini: 'А',
        component: ValidationForms
      },
      {
        path: '/forms/single-enrollment',
        component: EnrollmentForms,
        hidden: true,
        name: 'Материал',
        mini: 'М'
      }
    ]
  },
  { redirect: true, path: '/', pathTo: '/dashboard', name: 'Dashboard' }
]
export default dashboardRoutes

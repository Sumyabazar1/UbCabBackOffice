import React, { Component } from 'react'
import {
  Grid,
  Row,
  Col,
  FormGroup,
  ControlLabel,
  FormControl
} from 'react-bootstrap'
import Card from 'components/Card/Card.jsx'
import { Redirect } from 'react-router-dom'
import axios from 'axios'
import Button from 'components/CustomButton/CustomButton.jsx'
import Loader from 'components/Loader/Loader'
import { BASE_URL } from 'variables/Variables.jsx'

class LoginPage extends Component {
  constructor (props) {
    super(props)
    this.state = {
      emailLogin: '',
      emailErrorLogin: null,
      passwordLogin: '',
      passwordErrorLogin: null,
      cardHidden: true,
      redirectToReferrer: false,
      loading: false
    }
  }

  handleLoginEmail (event) {
    this.setState({
      emailLogin: event.target.value
    })
    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    re.test(event.target.value) === false
      ? this.setState({
        emailErrorLogin: (
          <small className='text-warning'>
              Имэйл хаягаа оруулна уу! Жишээ нь:<i>operator@ubcab.mn</i>.
          </small>
        )
      })
      : this.setState({ emailErrorLogin: null })
  }
  handleLoginPassword (event) {
    this.setState({
      passwordLogin: event.target.value
    })
    event.target.value.length < 6
      ? this.setState({
        passwordErrorLogin: (
          <small className='text-warning'>
              Нууц үгээ оруулна уу! 6-с дээш урттай
          </small>
        )
      })
      : this.setState({ passwordErrorLogin: null })
  }
  handleSubmit (event) {
    this.setState({ loading: true })
    event.preventDefault()
    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    re.test(this.state.emailLogin) === false
      ? this.setState({
        emailErrorLogin: (
          <small className='text-danger'>
              Имэйл хаягаа оруулна уу! Жишээ нь:<i>zoloo@ubcab.mn</i>.
          </small>
        )
      })
      : this.setState({ emailErrorLogin: null })
    this.state.passwordLogin < 6
      ? this.setState({
        passwordErrorLogin: (
          <small className='text-danger'>
              Нууц үгээ оруулна уу! 6-с дээш урттай
          </small>
        )
      })
      : this.setState({ passwordErrorLogin: null })
    const user = {
      email: this.state.emailLogin,
      password: this.state.passwordLogin
    }

    if (this.state.emailErrorLogin == null && this.state.passwordLogin) {
      axios.post(BASE_URL + 'operator/auth/login', user)
        .then((response) => {
          let userResponse = response.data
          if (userResponse) {
            sessionStorage.setItem('token', userResponse.token)
            this.setState({ redirectToReferrer: true })
          } else {
            this.setState({ passwordErrorLogin: (
              <small className='text-danger'>
            Имэйл хаяг нууц үгээ шалгана уу!
              </small>
            ) })
          }
          this.setState({ loading: false })
        }, this)
        .catch(() => {
          this.setState({ passwordErrorLogin: (
            <small className='text-danger'>
          Имэйл хаяг нууц үгээ шалгана уу!
            </small>
          ) })
          this.setState({ loading: false })
        })
    } else {
      this.setState({ passwordErrorLogin: (
        <small className='text-danger'>
      Имэйл хаяг нууц үгээ гүйцэт оруулна уу!
        </small>
      ) })
      this.setState({ loading: false })
    }
  }
  componentDidMount () {
    setTimeout(
      function () {
        this.setState({ cardHidden: false, loading: false })
      }.bind(this),
      200
    )
  }

  render () {
    if (this.state.redirectToReferrer) {
      return (<Redirect to={'/user'} />)
    }
    if (sessionStorage.getItem('token')) {
      return (<Redirect to={'/dashboard'} />)
    }
    return (
      <Grid>
        <Row>
          <Col md={4} sm={6} mdOffset={4} smOffset={3}>
            <Card
              hidden={this.state.cardHidden}
              textCenter
              title='Нэвтрэх'
              content={
                <div>
                  <Loader loading={this.state.loading} >
                    <form onSubmit={this.handleSubmit.bind(this)}>
                      <FormGroup>
                        <ControlLabel>Имэйл</ControlLabel>
                        <FormControl type='email' name='email' onChange={event => this.handleLoginEmail(event)} placeholder='Имэйл хаягаа оруул' required />
                        {this.state.emailErrorLogin}
                      </FormGroup>
                      <FormGroup>
                        <ControlLabel>Нууц үг</ControlLabel>
                        <FormControl type='password' name='password' onChange={event => this.handleLoginPassword(event)} placeholder='Нууц үгээ оруул' required />
                        {this.state.passwordErrorLogin}
                      </FormGroup>
                      <Button type='submit' round onClick={this.handleSubmit.bind(this)}>
                        Нэвтрэх
                      </Button>
                    </form>
                  </Loader>
                </div>
              }
            />
          </Col>
        </Row>
      </Grid>
    )
  }
}
export default LoginPage

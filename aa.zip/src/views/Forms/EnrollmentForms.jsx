import React, { Component } from 'react'
import Lightbox from 'react-lightbox-component'
import queryString from 'query-string'
import { BASE_URL } from 'variables/Variables.jsx'
import { CopyToClipboard } from 'react-copy-to-clipboard'

import {
  Grid,
  Row,
  Col,
  FormGroup,
  ControlLabel,
  FormControl,
  Form
} from 'react-bootstrap'

import Card from 'components/Card/Card.jsx'
import Loader from 'components/Loader/Loader.jsx'
import Button from 'components/CustomButton/CustomButton.jsx'
import Radio from 'components/CustomRadio/CustomRadio.jsx'
import axios from 'axios'

class RegularForms extends Component {
  constructor (props) {
    super(props)
    this.state = {
      radio: '1',
      formData: null,
      visible: false,
      loading: true,
      driverId: null,
      driverName: null,
      token: null,
      value: '',
      copied: false,
      registered: null
    }
    this.docSubmit = this.docSubmit.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.handleChange = this.handleChange.bind(this)
    this.parseDate = this.parseDate.bind(this)
  }

  docSubmit (items, prefix, index, doc) {
    // console.log(items, prefix, index)
    // this.preventDefault()
    this.setState({ loading: true })
    let docItemId = items[prefix * 10 + index]
    axios.post(BASE_URL + 'doc/' + this.state.driverId, { registered: this.state.registered, document: doc, docitem: docItemId, status: this.state[docItemId], extra: this.state[docItemId + 'reason'] },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.state.token
        }
      }
    )
      .then(data => {
        return this.setState({ loading: false })
      })
      .catch(() => {
        return this.setState({ loading: false })
      })
  }
  formSubmit (items, form, doc, prefix, len) {
    // console.log(items, prefix, len)
    this.setState({ loading: true })

    let data = []
    for (let i = prefix * 10; i < prefix * 10 + len; i++) {
      let singleItem = {}
      singleItem.key = form[items[i]].key
      singleItem.priority = form[items[i]].priority
      singleItem.type = form[items[i]].type
      singleItem.value = this.state[form[items[i]].key]
      data.push(singleItem)
    }
    axios.post(BASE_URL + 'info/' + this.state.driverId, { registered: this.state.registered, doc_key: doc, infos: data },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.state.token
        }
      }
    )
      .then(data => {
        return this.setState({ loading: false })
      })
      .catch(() => {
        return this.setState({ loading: false })
      })
  }
  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value })
    // console.log(event.target.value)
  }

  fetchData = (values) => {
    axios.get(BASE_URL + 'enrollment/' + values.id + '?registered=' + values.registered,
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.state.token
        }
      }
    )
      .then(data => {
        // console.log(data.data.allDocs)
        this.initData(data.data)
      })
      .catch(() => {
        this.setState({ loading: false })
        sessionStorage.removeItem('token')
        return this.props.history.push('/pages/login-page')
      })
  }
  componentWillMount = () => {
    if (sessionStorage.getItem('token')) {
      this.setState({ token: sessionStorage.getItem('token') })
    }
  }
  componentDidMount = () => {
    let values = queryString.parse(this.props.location.search)
    this.setState({ driverId: values.id, registered: values.registered })
    this.fetchData(values)
  }
  parseDate = (value) => {
    if (value) return value.substring(0, 10)
    else return ''
  }
  renderLightBox = (src, title, desc, date) => {
    return (
      <div>
        <Lightbox images={
          [
            {
              src: src + '?' + date,
              title: title,
              description: desc
            }
          ]
        } />
      </div>
    )
  }
  initData=(data) => {
    let _this = this
    data.required_doc_names.map(function (item, index) {
      Object.keys(data.required_docs[item].docitems).map(function (key, ind) {
        _this.setState({ [key]: data.required_docs[item].docitems[key].status })
        _this.setState({ [key.concat('reason')]: data.required_docs[item].docitems[key].extra })
      })
      data.required_docs[item].fetch_keys.map(function (k, i) {
        _this.setState({ [k]: data.required_docs[item].fetch_data[k].value })
      })
    })
    this.setState({ driverId: data.driver_id, driverName: data.driver_name })
    this.setState({ formData: data, loading: false })
    return true
  }

  body = (formData) => {
    let _this = this
    let docItems = []
    let formItems = []
    let order = 0
    return (
      formData.required_doc_names.map(function (item, index) {
        order++
        return <Row key={index}>
          <Col md={6}>
            <Card
              title={order.toString().concat('. ' + formData.required_docs[item].name) + '-' + (formData.required_docs[item].status == 300 ? 'Илгээсэн(300)' : formData.required_docs[item].status == 400 ? 'Дутуу(400)' : formData.required_docs[item].status == 500 ? 'Буцаасан(500)' : formData.required_docs[item].status == 200 ? 'Баталгаажсан(200)' : 'Тодорхойгүй(0)')}
              content={
                <Row>
                  { Object.keys(formData.required_docs[item].docitems).map(function (key, ind) {
                    docItems[index * 10 + ind] = key
                    return <Col md={6}><form>
                      <div className='pull-right' >
                        {_this.renderLightBox(formData.required_docs[item].docitems[key].fullpath, key, formData.required_docs[item].name, formData.required_docs[item].docitems[key].updatedAt)}
                        <CopyToClipboard className='pull-right' text={formData.required_docs[item].docitems[key].fullpath}>
                          <span style={{ cursor: 'pointer' }}><i class='pe-7s-copy-file' /></span>
                        </CopyToClipboard>
                      </div>
                      <FormGroup>
                        <div>
                          {formData.required_docs[item].docitems[key].status == 300 ? 'Илгээсэн(300)' : formData.required_docs[item].docitems[key].status == 400 ? 'Дутуу(400)' : formData.required_docs[item].docitems[key].status == 500 ? 'Буцаасан(500)' : formData.required_docs[item].docitems[key].status == 200 ? 'Баталгаажсан(200)' : 'Тодорхойгүй(0)'}
                        </div>
                        <Radio
                          number={key.concat(1)}
                          name={key}
                          option='200'
                          checked={_this.state[key] == 200}
                          onChange={_this.handleChange}
                          label='Accept'
                        />
                        <Radio
                          number={key.concat(2)}
                          name={key}
                          option='500'
                          checked={_this.state[key] == 500}
                          onChange={_this.handleChange}
                          label='Reject'
                        />
                        <textarea className='form-control' name={key.concat('reason')} type='textarea' placeholder='Шалтгаан' onChange={_this.handleChange} value={_this.state[key.concat('reason')]} />
                      </FormGroup>
                      <FormGroup>
                        <Button onClick={() => {
                          _this.docSubmit(docItems, index, ind, item)
                        }} bsStyle='info' fill>
                      Хадгалах
                        </Button>
                      </FormGroup>
                    </form>
                    </Col>
                  })}
                </Row>
              }
            />
          </Col>
          <Col md={6}>
            <Card
              title='Засварлах утга'
              content={
                <Form horizontal>
                  {formData.required_docs[item].fetch_keys.map(function (k, i) {
                    formItems[index * 10 + i] = k
                    return <FormGroup>
                      <ControlLabel className='col-md-6'>{formData.required_docs[item].fetch_data[k].name}</ControlLabel>
                      <Col md={6}>
                        <FormControl name={k} placeholder={formData.required_docs[item].fetch_data[k].name} type={formData.required_docs[item].fetch_data[k].type} onChange={_this.handleChange} value={formData.required_docs[item].fetch_data[k].type === 'date' ? _this.parseDate(_this.state[k]) : _this.state[k]} />
                      </Col>
                    </FormGroup>
                  })}
                  <FormGroup>
                    <Col md={8} mdOffset={4}>
                      <Button onClick={() => {
                        _this.formSubmit(formItems, formData.required_docs[item].fetch_data, item, index, formData.required_docs[item].fetch_keys.length)
                      }} bsStyle='info' fill>
                    Хадгалах
                      </Button>
                    </Col>
                  </FormGroup>
                </Form>
              }
            />
          </Col>
        </Row>
      })
    )
  }

  render () {
    let { formData } = this.state
    if (formData === null) {
      return <div className='main-content'><Loader loading={this.state.loading} /></div>
    }
    return (
      <div><br /><Loader loading={this.state.loading}>
        <Row style={{ textAlign: 'center' }}>{this.state.driverName}
        </Row>
        <div className='main-content'>
          <Grid fluid>
            {this.body(formData)}
          </Grid>
        </div>
      </Loader>
      </div>
    )
  }
}

export default RegularForms

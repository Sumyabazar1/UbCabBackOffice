import React, { Component } from 'react'
// react component for creating dynamic tables
import ReactTable from 'react-table'
import { Grid, Row, Col, Form, FormGroup, InputGroup, FormControl, OverlayTrigger, Tooltip } from 'react-bootstrap'
import axios from 'axios'
import Card from 'components/Card/Card.jsx'
import { BASE_URL } from 'variables/Variables.jsx'
import Button from 'components/CustomButton/CustomButton.jsx'
import moment from 'moment'

class Drivers extends Component {
  constructor (props) {
    super(props)
    this.state = {
      data: [],
      pages: null,
      loading: true,
      token: null,
      search: null
    }
    this.fetchData = this.fetchData.bind(this)
  }
  componentWillMount = () => {
    if (sessionStorage.getItem('token')) {
      this.setState({ token: sessionStorage.getItem('token') })
    }
  }
  searchDriver = (e) => {
    e.preventDefault()
    this.fetchData({ pageSize: 10,
      page: 0,
      sorted: [],
      filtered: this.state.search ? [{ id: 'name', value: this.state.search }] : [],
      isRegistered: false })
    console.log(this.state.search)
  }
  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value })
    // console.log(event.target.value)
  }

  fetchData (state, instance) {
    this.setState({ loading: true })
    // Request the data however you want.  Here, we'll use our mocked service we created earlier
    axios.post(BASE_URL + 'drivers',
      {
        pageSize: state.pageSize,
        page: state.page,
        sorted: [{ id: 'createdAt', desc: 1 }],
        filtered: state.filtered,
        isRegistered: false
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.state.token
        }
      })
      .then(res => {
      // Now just get the rows of data to your React Table (and update anything else like total pages or loading)
        this.setState({
          data: res.data.itemsList,
          pages: res.data.pageCount,
          loading: false
        })
      }).catch(() => {
        sessionStorage.removeItem('token')
        return this.props.history.push('/pages/login-page')
      })
  }

  render () {
    const { data, pages, loading } = this.state
    const view = <Tooltip id='view'>Дэлгэрэнгүй</Tooltip>
    const edit = <Tooltip id='edit'>Засах</Tooltip>
    const remove = <Tooltip id='remove'>Устгах</Tooltip>
    return (
      <div className='main-content'>
        <Grid fluid>
          <Row>
            <Col md={12}>
              <Form pullRight className='navbar-search-form' onSubmit={this.searchDriver}>
                <FormGroup>
                  <InputGroup>
                    <InputGroup.Addon>
                      <i className='fa fa-search' />
                    </InputGroup.Addon>
                    <FormControl name='search' type='text' onChange={this.handleChange} value={this.state.search} placeholder='Хайлт...' />
                  </InputGroup>
                </FormGroup>
              </Form>
              <Card
                title='Жолооч'
                content={
                  <ReactTable
                    filterable
                    columns={[
                      {
                        Header: 'Овог Нэр',
                        accessor: 'name',
                        sortable: false,
                        filterable: false
                      },
                      {
                        Header: 'Имэйл',
                        accessor: 'email',
                        sortable: false,
                        filterable: false
                      },
                      {
                        accessor: 'car_registration_number',
                        Header: 'Дугаар',
                        sortable: false,
                        filterable: false
                      },
                      {
                        accessor: 'phone_number',
                        Header: 'Утас',
                        sortable: false,
                        filterable: false
                      },
                      {
                        id: 'createdAt',
                        Header: 'Үүссэн',
                        sortable: false,
                        filterable: false,
                        accessor: d => {
                          return moment(d.createdAt)
                            .local()
                            .format('YYYY-MM-DD HH:mm:ss')
                        }
                      },
                      {
                        Header: 'Төлөв',
                        accessor: 'status',
                        sortable: false,
                        filterable: false,
                        Cell: (props) => {
                          return <span>{props.original.status == 300 ? 'Илгээсэн(300)' : props.original.status == 400 ? 'Дутуу(400)' : props.original.status == 500 ? 'Буцаасан(500)' : props.original.status == 200 ? 'Идэвхтэй(200)' : 'Тодорхойгүй(0)'}</span>
                        }
                      },
                      {
                        sortable: false,
                        filterable: false,
                        width: 100,
                        Cell: row => (
                          <td className='td-actions text-right'>
                            <OverlayTrigger placement='top' overlay={view}>
                              <Button simple bsStyle='info' bsSize='xs'>
                                <i className='fa fa-user' />
                              </Button>
                            </OverlayTrigger>
                            <OverlayTrigger placement='top' overlay={edit} onClick={() => this.props.history.push('/forms/single-enrollment?id=' + row.row._original.id + '&registered=false')}>
                              <Button simple bsStyle='success' bsSize='xs'>
                                <i className='fa fa-edit' />
                              </Button>
                            </OverlayTrigger>
                            <OverlayTrigger placement='top' overlay={remove}>
                              <Button simple bsStyle='danger' bsSize='xs' onClick={() => this.props.history.push('/enrollment/')}>
                                <i className='fa fa-times' />
                              </Button>
                            </OverlayTrigger>
                          </td>
                        )
                      }
                    ]}
                    manual
                    data={data}
                    nextText='Дараагийн'
                    previousText='Өмнөх'
                    pageText='Хуудас'
                    loadingText='Түр хүлээнэ үү'
                    noDataText='Утга байхгүй байна'
                    ofText='/'
                    rowsText=''
                    pages={pages}
                    loading={loading}
                    onFetchData={this.fetchData}
                    defaultPageSize={10}
                    showPaginationTop={false}
                    showPaginationBottom
                    className='-striped -highlight'
                  />
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}

export default Drivers

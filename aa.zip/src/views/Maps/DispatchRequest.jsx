import React, { Component } from 'react'
import { Grid, Row, Col, InputGroup, FormGroup, FormControl, Form } from 'react-bootstrap'
// react components used to create a google map
import Stomp from 'stompjs'
import car from '../../assets/img/car.svg'
import { BASE_URL } from 'variables/Variables.jsx'
import { throttle, debounce } from 'throttle-debounce'

import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker
} from 'react-google-maps'

import Card from 'components/Card/Card.jsx'
import MapCard from 'components/Card/MapCard.jsx'
import Loader from 'components/Loader/Loader.jsx'
import Button from 'components/CustomButton/CustomButton.jsx'
import axios from 'axios'
import Select from 'react-select'
import 'react-select/dist/react-select.css'

const { compose, withProps } = require('recompose')
const MapWithAMarker = compose(
  withProps({
    googleMapURL: 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDKoeDdvtV-eM5my9F_UrrGbHulVdJ8s_8&v=3.exp&libraries=geometry,drawing',
    loadingElement: <div style={{ height: `90%` }} />,
    containerElement: <div style={{ height: `90vh` }} />,
    mapElement: <div style={{ height: `90vh` }} />
  }),
  withScriptjs,
  withGoogleMap
)(props =>
  <GoogleMap
    defaultZoom={15}
    defaultCenter={{ lat: 47.9123565, lng: 106.9151432 }}
  >
    <Marker
      name='pin'
      draggable
      onDragEnd={props.onMarkerDragEnd}
      position={{ lat: props.pin.location.lat, lng: props.pin.location.lng }}
    />
    {props.markers.map(item => (
      <Marker
        icon={{
          url: car,
          scaledSize: { height: 24, width: 24 },
          anchor: { x: 12, y: 12 },
          rotation: item.body.bearing

        }}
        key={item.id}
        position={{ lat: item.body.lat, lng: item.body.lng }}
      />
    ))}

  </GoogleMap>
)

class DispatchRequest extends Component {
  constructor (props) {
    super(props)
    // randomUserId is used to emulate a unique user id for this demo usage
    this.state = {
      clientConnected: false,
      messages: [],
      connection: null,
      markers: [],
      address: null,
      phone: null,
      token: null,
      suggestions: [],
      singleSelect: '',
      pin: { location: { lat: 47.9123565, lng: 106.9151432 }, text: 'Төв цэг' }
    }
    this.addressSearchThrottled = throttle(1200, this.searchAddress)
  }

  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value })
    // console.log(event.target.value)
  }
  handleMarkerDrag = (e) => {
    console.log(e.latLng.lat(), e.latLng.lng())
    this.searchLatLng(e.latLng.lat(), e.latLng.lng())
  }
  changeQuery = event => {
    console.log('hi')
    if (event != '') {
      this.setState({ address: event }, () => {
        this.addressSearchThrottled(this.state.address)
      })
    }
  }
  handleQuery = value => {
    if (value != null) {
      this.state.suggestions.map(item => {
        if (item.value === value.value) { return this.setState({ pin: { location: { lat: item.location.lat, lng: item.location.lng }, text: item.label }, singleSelect: value }) }
      })
    }
  }
  searchAddress = (e) => {
    // e.preventDefault()
    console.log(e)
    if (e != '') {
      axios.get('https://ef7ws7od4b.execute-api.eu-central-1.amazonaws.com/production/address?search=' + e,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjViZGFkZTdiMjA1YThmZWIwOTE2ZGM3ZSIsInN0YW1wIjoxNTQ0MTA1MjM0MjgxLCJ0eXBlIjoicmlkZXIiLCJpYXQiOjE1NDQxMDUyMzQsImV4cCI6MTU0NDE5MTYzNH0.-F7mN_ZldhgW2qvQT8vlP4AofG8OGyw0Pr6R34A5QiM'
          }
        }
      )
        .then(data => {
          let searchResult = []
          data.data.result.map(item => {
            searchResult.push({ value: item._id, label: item._source.address_short_mn + ' ' + item._source.address_normal_en, location: { lat: item._source.location.lat, lng: item._source.location.lon } })
          })
          this.setState({ suggestions: searchResult })
        })
        .catch(() => {
          this.setState({
            suggestions: []
          })
        })
    }
  }
  searchLatLng = (lat, lng) => {
    // e.preventDefault()
    // console.log(this.state.token)
    axios.get('https://ef7ws7od4b.execute-api.eu-central-1.amazonaws.com/production/address?lat=' + lat + '&lon=' + lng,
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjViZGFkZTdiMjA1YThmZWIwOTE2ZGM3ZSIsInN0YW1wIjoxNTQ0MTA1MjM0MjgxLCJ0eXBlIjoicmlkZXIiLCJpYXQiOjE1NDQxMDUyMzQsImV4cCI6MTU0NDE5MTYzNH0.-F7mN_ZldhgW2qvQT8vlP4AofG8OGyw0Pr6R34A5QiM'
        }
      }
    )
      .then(data => {
        let searchResult = []
        data.data.result.map(item => {
          searchResult.push({ value: item._id, label: item._source.address_short_mn + ' ' + item._source.address_normal_en, location: { lat: item._source.location.lat, lng: item._source.location.lon } })
        })
        this.setState({ suggestions: searchResult, singleSelect: searchResult[0].value, pin: { location: { lat: searchResult[0].location.lat, lng: searchResult[0].location.lng }, text: searchResult[0].label } })
      })
      .catch(() => {

      })
  }
  /* calcNextPosition (prev, next) {
    if (this.state.currentIdx === 4) {
      this.setState({ currentIdx: 0 })
    } else {
      this.setState({ currentIdx: this.state.currentIdx + 1 }, function () {
        var latDelta = (next.body.lat - prev.body.lat) / 5
        var lngDelta = (next.body.lng - prev.body.lng) / 5
        var bearingDelta = (next.body.bearing - prev.body.bearing) / 5
        var nextPos = { bearing: prev.body.bearing + (bearingDelta * this.state.currentIdx), lat: prev.body.lat + (latDelta * this.state.currentIdx), lng: prev.body.lng + (lngDelta * this.state.currentIdx) }
        this.setState({ currentPos: nextPos })
      })
    }
  }

  updatePosition () {
    this.calcNextPosition()
    console.log('Current position: ' + JSON.stringify(this.state.currentPos))
  } */
  searchDriver = () => {
    axios.get(BASE_URL + 'info/' + this.state.driverSearchText,
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.state.token
        }
      }
    )
      .then(data => {
        return this.setState({ loading: false })
      })
      .catch(() => {
        return this.setState({ loading: false })
      })
  }
  subscribe = () => {
    this.state.connection.subscribe('/exchange/templocation/*.*.*', (message) => {
      let body = JSON.parse(message.body)
      let arr = message.headers.destination.split('.')
      let newMarker = {}
      newMarker.id = arr[1]
      newMarker.body = body
      let found = false
      this.setState(state => {
        const markers = state.markers.map((item, j) => {
          if (item.id === arr[1]) {
            found = true
            return newMarker
          } else {
            return item
          }
        })
        if (!found) {
          const added = state.markers.push(newMarker)
          return added
        } else {
          return {
            markers
          }
        }
      })
    })
  }
  connectRabbit = (client) => {
    // scope.ws = ws;
    // scope.client = client;

    // SockJS does not support heart-beat: disable heart-beats
    client.heartbeat.outgoing = 20000
    client.heartbeat.incoming = 0

    client.connect('admin', 'adminubcab1231',
      () => {
        return this.subscribe()
      },
      (err) => {
        return console.log('error connecting to RabbitMQ:', err)
      }, '/')
  }
  componentWillMount = () => {
    var ws = new WebSocket('ws://ubcabrabbit.eu-central-1.elasticbeanstalk.com:12345/ws')
    var client = Stomp.over(ws)
    if (sessionStorage.getItem('token')) {
      this.setState({ token: sessionStorage.getItem('token'), connection: client })
    } else { this.setState({ connection: client }) }
    this.connectRabbit(client)
  }
  componentWillUnmount = () => {
    this.state.connection.disconnect()
  }

  render () {
    return (
      <div className='main-content'>
        <Grid fluid>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <Row>
                    <Col md={12}>
                      <Col md={3}>
                        <FormGroup>
                          <FormControl name='driverSearchText' type='text' onChange={this.handleChange} value={this.state.driverSearchText} placeholder='Улсын дугаар эсвэл утас' />
                        </FormGroup>
                        <div>Байршлаа илгээж байгаа: {this.state.markers.length}</div>
                      </Col>
                      <Col md={1}>
                        <Button onClick={() => {
                          this.searchDriver()
                        }} bsStyle='info' fill>
                      Хайх
                        </Button>
                      </Col>
                      <Col md={3}>

                        <Select
                          placeholder='Хаяг хайлт'
                          name='singleSelect'
                          value={this.state.singleSelect}
                          options={this.state.suggestions}
                          onInputChange={this.changeQuery}
                          onChange={this.handleQuery}
                        />

                      </Col>
                      <Col md={2}>
                        <FormGroup>
                          <textarea className='form-control' name='additional' type='textarea' placeholder='Нэмэлт мэдээлэл' onChange={this.handleChange} value={this.state.additional} />
                        </FormGroup>
                      </Col>
                      <Col md={2}>
                        <FormGroup>
                          <FormControl name='phone' type='text' onChange={this.handleChange} value={this.state.phone} placeholder='Утасны дугаар' />
                        </FormGroup>
                      </Col>
                      <Col md={1}>
                        <FormGroup>
                          <Button onClick={() => {
                          }} bsStyle='warning' fill>
                      Дуудах
                          </Button>

                        </FormGroup>

                      </Col>
                    </Col>
                  </Row>
                }
              />
            </Col>
          </Row>
          <div>
            <Loader loading={this.state.loading}>
              <Row>
                <Col md={12}>
                  <MapCard
                    title=''
                    content={
                      <MapWithAMarker markers={this.state.markers} pin={this.state.pin} onMarkerDragEnd={this.handleMarkerDrag} />
                    }
                  />
                </Col>
              </Row>
            </Loader>
          </div>
        </Grid>
      </div>
    )
  }
}

export default DispatchRequest

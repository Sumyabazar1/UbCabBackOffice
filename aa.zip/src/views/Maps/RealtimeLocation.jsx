import React, { Component } from 'react'
import { Grid, Row, Col } from 'react-bootstrap'
// react components used to create a google map
import Stomp from 'stompjs'
import car from '../../assets/img/car.svg'
import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker
} from 'react-google-maps'

import MapCard from 'components/Card/MapCard.jsx'
const { compose, withProps } = require('recompose')

const MapWithAMarker = compose(
  withProps({
    googleMapURL: 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDKoeDdvtV-eM5my9F_UrrGbHulVdJ8s_8&v=3.exp&libraries=geometry,drawing',
    loadingElement: <div style={{ height: `100%` }} />,
    containerElement: <div style={{ height: `100vh` }} />,
    mapElement: <div style={{ height: `100vh` }} />
  }),
  withScriptjs,
  withGoogleMap
)(props =>
  <GoogleMap
    defaultZoom={15}
    defaultCenter={{ lat: 47.9123565, lng: 106.9151432 }}
  >

    {props.markers.map(item => (
      <Marker
        icon={{
          url: car,
          scaledSize: { height: 24, width: 24 },
          anchor: { x: 12, y: 12 },
          rotation: item.body.bearing

        }}
        key={item.id}
        position={{ lat: item.body.lat, lng: item.body.lng }}
      />
    ))}

  </GoogleMap>
)

class RealtimeLocation extends Component {
  constructor (props) {
    super(props)
    // randomUserId is used to emulate a unique user id for this demo usage
    this.state = {
      clientConnected: false,
      messages: [],
      connection: null,
      markers: [],
      token: null
    }
  }
  /* calcNextPosition (prev, next) {
    if (this.state.currentIdx === 4) {
      this.setState({ currentIdx: 0 })
    } else {
      this.setState({ currentIdx: this.state.currentIdx + 1 }, function () {
        var latDelta = (next.body.lat - prev.body.lat) / 5
        var lngDelta = (next.body.lng - prev.body.lng) / 5
        var bearingDelta = (next.body.bearing - prev.body.bearing) / 5
        var nextPos = { bearing: prev.body.bearing + (bearingDelta * this.state.currentIdx), lat: prev.body.lat + (latDelta * this.state.currentIdx), lng: prev.body.lng + (lngDelta * this.state.currentIdx) }
        this.setState({ currentPos: nextPos })
      })
    }
  }

  updatePosition () {
    this.calcNextPosition()
    console.log('Current position: ' + JSON.stringify(this.state.currentPos))
  } */
  subscribe = () => {
    this.state.connection.subscribe('/exchange/templocation/*.*.*', (message) => {
      let body = JSON.parse(message.body)
      let arr = message.headers.destination.split('.')
      let newMarker = {}
      newMarker.id = arr[1]
      newMarker.body = body
      let found = false
      this.setState(state => {
        const markers = state.markers.map((item, j) => {
          if (item.id === arr[1]) {
            found = true
            return newMarker
          } else {
            return item
          }
        })
        if (!found) {
          const added = state.markers.push(newMarker)
          return added
        } else {
          return {
            markers
          }
        }
      })
    })
  }
  connectRabbit = (client) => {
    // scope.ws = ws;
    // scope.client = client;

    // SockJS does not support heart-beat: disable heart-beats
    client.heartbeat.outgoing = 20000
    client.heartbeat.incoming = 0

    client.connect('admin', 'adminubcab1231',
      () => {
        return this.subscribe()
      },
      (err) => {
        return console.log('error connecting to RabbitMQ:', err)
      }, '/')
  }
  componentWillMount = () => {
    var ws = new WebSocket('ws://rabbitmq.eu-central-1.elasticbeanstalk.com:12345/ws')
    var client = Stomp.over(ws)
    this.setState({ connection: client })
    this.connectRabbit(client)
  }
  componentWillUnmount = () => {
    this.state.connection.disconnect()
  }

  render () {
    return (
      <div className='main-content'>
        <Grid fluid>
          <Row><div>
            {this.state.markers.length}
          </div></Row>
          <Row>
            <Col md={12}>
              <MapCard
                title=''
                content={
                  <MapWithAMarker markers={this.state.markers} />
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}

export default RealtimeLocation
